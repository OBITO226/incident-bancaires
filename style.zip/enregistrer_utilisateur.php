<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "incidents_bancaires");
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Récupération et sécurisation des données
$nom = htmlspecialchars($_POST['nom']);
$prenom = htmlspecialchars($_POST['prenom']);
$email = htmlspecialchars($_POST['email']);
$role = htmlspecialchars($_POST['role']);
$motdepasse = password_hash($_POST['motdepasse'], PASSWORD_DEFAULT);

// Insertion dans la base
$sql = "INSERT INTO utilisateurs (Nom, Prenom, Email, Role, MotDePasse) 
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $nom, $prenom, $email, $role, $motdepasse);

if ($stmt->execute()) {
    echo "✅ Utilisateur enregistré avec succès.";
} else {
    echo "❌ Erreur : " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
