<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Entreprises Bancaires - Incidents UEMOA</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        #searchInput, .form-input, #addButton {
            margin-bottom: 10px;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
        }
        #addButton {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        #addButton:hover {
            background-color: #0056b3;
        }
        .success-message {
            color: green;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Entreprises Bancaires Touchées dans l'Espace UEMOA</h1>

    <!-- 🔍 Recherche -->
    <input type="text" id="searchInput" onkeyup="filterTable()" placeholder="Rechercher une entreprise ou un incident...">

    <!-- 📋 Tableau au-dessus -->
    <table id="incidentTable">
        <thead>
            <tr>
                <th>Nom de l'Entreprise</th>
                <th>Pays</th>
                <th>Type d'Incident</th>
                <th>Date</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <!-- Exemples initiaux -->
            <tr>
                <td>Banque Côte d'Ivoire</td>
                <td>Côte d'Ivoire</td>
                <td>Panne Systémique</td>
                <td>06/04/2025</td>
                <td>Résolu</td>
            </tr>
            <tr>
                <td>Banque Sénégal</td>
                <td>Sénégal</td>
                <td>Cyberattaque</td>
                <td>05/04/2025</td>
                <td>En cours</td>
            </tr>
        </tbody>
    </table>

    <!-- 📝 Formulaire en dessous -->
    <h2>Ajouter une nouvelle entreprise</h2>
    <input type="text" id="entreprise" class="form-input" placeholder="Nom de l'entreprise">
    <input type="text" id="pays" class="form-input" placeholder="Pays">
    <input type="text" id="type" class="form-input" placeholder="Type d'incident">
    <input type="text" id="statut" class="form-input" placeholder="Statut">
    <button id="addButton" onclick="addIncident()">Ajouter une entreprise</button>
    <div id="message" class="success-message"></div>

    <script>
        function filterTable() {
            const input = document.getElementById("searchInput").value.toUpperCase();
            const rows = document.querySelectorAll("#incidentTable tbody tr");

            rows.forEach(row => {
                const cells = row.querySelectorAll("td");
                let visible = false;

                cells.forEach(cell => {
                    if (cell.innerText.toUpperCase().includes(input)) {
                        visible = true;
                    }
                });

                row.style.display = visible ? "" : "none";
            });
        }

        function getTodayDateForDB() {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        function formatDateForDisplay(ymd) {
            const parts = ymd.split("-");
            return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }

        function addIncident() {
            const entreprise = document.getElementById("entreprise").value.trim();
            const pays = document.getElementById("pays").value.trim();
            const type = document.getElementById("type").value.trim();
            const statut = document.getElementById("statut").value.trim();
            const date = getTodayDateForDB();

            if (!entreprise || !pays || !type || !statut) {
                alert("Veuillez remplir tous les champs.");
                return;
            }

            fetch("ajouter_incident.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ entreprise, pays, type, date, statut })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const table = document.getElementById("incidentTable").getElementsByTagName("tbody")[0];
                    const newRow = table.insertRow();

                    newRow.innerHTML = `
                        <td>${entreprise}</td>
                        <td>${pays}</td>
                        <td>${type}</td>
                        <td>${formatDateForDisplay(date)}</td>
                        <td>${statut}</td>
                    `;

                    document.getElementById("message").textContent = data.message;
                    document.getElementById("entreprise").value = "";
                    document.getElementById("pays").value = "";
                    document.getElementById("type").value = "";
                    document.getElementById("statut").value = "";
                } else {
                    alert("Erreur lors de l'ajout : " + data.message);
                }
            })
            .catch(error => {
                console.error("Erreur :", error);
                alert("Échec de l'enregistrement.");
            });
        }
    </script>
</body>
</html>
