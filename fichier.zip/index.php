<?php
session_start();
$host = 'localhost';
$dbname = 'incidents_bancaires';
$user = 'root';  // Change si nécessaire
$pass = '';      // Change si nécessaire

$conn = new mysqli($host, $user, $pass, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_utilisateur = $_POST['nom_utilisateur'];
    $mot_de_passe = $_POST['mot_de_passe'];

    $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE nom_utilisateur = ?");
    $stmt->bind_param("s", $nom_utilisateur);
    $stmt->execute();
    $result = $stmt->get_result();
    $utilisateur = $result->fetch_assoc();

    if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
        // Créer la session pour l'utilisateur connecté
        $_SESSION['utilisateur'] = $utilisateur['nom_utilisateur'];
        $_SESSION['role'] = $utilisateur['role'];

        // Redirection vers le tableau de bord
        header("Location: tableau.php");
        exit;
    } else {
        $message = "Identifiants incorrects.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion - Portail IB BANK</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-100 to-blue-300 min-h-screen flex items-center justify-center">

  <form method="POST" class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center text-blue-800">Connexion au Portail</h2>

    <?php if (!empty($message)) echo "<p class='text-red-500 mb-4 text-sm text-center'>$message</p>"; ?>

    <div class="mb-4">
      <label class="block text-sm font-semibold mb-1 text-gray-700">Nom d'utilisateur</label>
      <input type="text" name="nom_utilisateur" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
    </div>

    <div class="mb-6">
      <label class="block text-sm font-semibold mb-1 text-gray-700">Mot de passe</label>
      <input type="password" name="mot_de_passe" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
    </div>

    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-md transition duration-200">
      Se connecter
    </button>
  </form>

</body>
</html>
